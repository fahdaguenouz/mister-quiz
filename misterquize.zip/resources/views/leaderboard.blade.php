@extends('app')

@section('content')

<table>
<p>hello there </p>
</table>

@endsection